﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TimeTable
{
    public partial class viewSession : MetroFramework.Forms.MetroForm
    {
        public viewSession()
        {
            InitializeComponent();
        }

        private void Combobuilding_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void MetroLabel1_Click(object sender, EventArgs e)
        {

        }
    }
}
