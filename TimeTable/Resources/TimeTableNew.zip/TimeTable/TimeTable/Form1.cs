﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TimeTable
{
    public partial class Form1 : MetroFramework.Forms.MetroForm
    {
        private Button currentButton;
        private Random random;
        private int tempIndex;


        public Form1()
        {
            InitializeComponent();
        }

        private void MetroLabel1_Click(object sender, EventArgs e)
        {

        }

        private void MetroButton10_Click(object sender, EventArgs e)
        {

        }

        private void MetroButton9_Click(object sender, EventArgs e)
        {
                    }

        private void dashboard_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form f1 = new Form1();
            f1.Show();
        }

        private void Button5_Click(object sender, EventArgs e)
        {

        }

        private void MetroPanel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void MetroTile1_Click(object sender, EventArgs e)
        {

        }

        private void MetroButton2_Click(object sender, EventArgs e)
        {

        }

        private void MetroButton1_Click(object sender, EventArgs e)
        {

        }

        private void student_Click(object sender, EventArgs e)
        {
            //this.Hide();
            //Student student = new Student();
            //student.Show();

        }

        private void Subjects_Click(object sender, EventArgs e)
        {
            this.Hide();
            AddSubjects addsub = new AddSubjects();
            addsub.Show();
        
    }

        private void Lectures_Click(object sender, EventArgs e)
        {
            this.Hide();
            AddLecturer addlec = new AddLecturer();
           addlec.Show();
            
        }

        private void Lecbtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            AddLecturer addlec = new AddLecturer();
            addlec.Show();

        }

        private void Subjectbtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            AddSubjects addsub = new AddSubjects();
            addsub.Show();

        }

        private void Sessionbtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            Addsession addsession = new Addsession();
            addsession.Show();

        }
    }
}
